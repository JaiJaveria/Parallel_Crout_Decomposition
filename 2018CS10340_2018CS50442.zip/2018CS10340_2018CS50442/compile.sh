gcc -g -O0 -fopenmp -o crout crout.c
